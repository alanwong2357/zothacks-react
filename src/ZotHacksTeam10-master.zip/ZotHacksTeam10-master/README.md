# ZotHacksTeam10


##Combining Social Media into one interface

### Project Ideas:

- Normal social media platforms seeing popular posts
- Search function combining all posts from a person you searched for
- Compiling all messages/direct messages received
- Currently: Reddit and Facebook

Cameron To-Do:
- Implement Posts user is following
    - Title
    - Comments
    - 
